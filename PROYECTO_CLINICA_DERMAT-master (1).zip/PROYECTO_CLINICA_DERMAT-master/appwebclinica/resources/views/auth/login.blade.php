<x-guest-layout>
    <!-- agregamos este link para registrar usuario-->
    <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
    
                            <a href="{{ route('register') }}" class="ml-4 text-sm text-gray-700 dark:text-gray-500 underline">-REGISTRARSE</a>
                           
                        
    </div>
    <x-jet-authentication-card>
        <x-slot name="logo">
        <img src="{{ asset('logo.jpg') }}" style="width: 200px; height: 200px; border: 2px solid #7FB3D5" class="img-responsive img-rounded" alt="mi logo">
        </x-slot>

        <x-jet-validation-errors class="mb-4" />

        @if (session('status'))
            <div class="mb-4 font-medium text-sm text-green-600">
                {{ session('status') }}
            </div>
        @endif

        <form method="POST" action="{{ route('login') }}">
            @csrf

            <div>
                <x-jet-label for="email" value="{{ __('Email') }}" />
                <x-jet-input id="email" class="block mt-1 w-full" type="email" name="email" :value="old('email')" required autofocus />
            </div>

            <div class="mt-4">
                <x-jet-label for="password" value="{{ __('Contraseña') }}" />
                <x-jet-input id="password" class="block mt-1 w-full" type="password" name="password" required autocomplete="current-password" />
            </div>

            <div class="block mt-4">
                <label for="remember_me" class="flex items-center">
                    <x-jet-checkbox id="remember_me" name="remember" />
                    <span class="ml-2 text-sm text-gray-600">{{ __('RECORDAR MI CONTRASEÑA') }}</span>
                </label>
            </div>

            <div class="flex items-center justify-end mt-4">
                @if (Route::has('password.request'))
                    <a class="underline text-sm text-gray-600 hover:text-gray-900" href="{{ route('password.request') }}">
                        {{ __('HAS OLVIDADO TU CONTRASEÑA?') }}
                    </a>
                @endif

                <x-jet-button class="ml-4">
                    {{ __('ENTRAR') }}
                </x-jet-button>
            </div>
        </form>
    </x-jet-authentication-card>
</x-guest-layout>
