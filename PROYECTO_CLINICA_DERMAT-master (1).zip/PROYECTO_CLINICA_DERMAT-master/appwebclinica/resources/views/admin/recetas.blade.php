@extends('adminlte::page')

@section('title', 'App web Clinica')

@section('content_header')
    <h1 class="">App Clinica Web recetas </h1> 
   
@stop

@section('content')
    <p>Welcome to this beautiful sayron esta aqui. EN RECETAS carpeta admin </p>

    
    

@stop


@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script> console.log('Hi!'); </script>
@stop
