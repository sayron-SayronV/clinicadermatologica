@extends('adminlte::page')

@section('title', 'App web Clinica')

@section('content_header')
    <h1 class="">App Clinica Web REPORTES DE INGRESOS </h1> 
   
@stop

@section('content')
    <p>Welcome to this beautiful sayron esta aqui. EN REPORTES DE INGRESOS carpeta admin </p>

    
    

@stop


@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script> console.log('Hi!'); </script>
@stop
