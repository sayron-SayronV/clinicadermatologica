@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1>crear consulta</h1>
@stop

@section('content')
    <p>Welcome to this beautiful admin panel  en la carpeta crud index   jajajaj</p>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script> console.log('Hi!'); </script>
@stop
