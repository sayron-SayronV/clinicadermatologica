La carpeta appwebclinica contiene el proyecto con framework laravel 8.
La carpeta api_clinica_der contiene las apis en nodejs.
Script de la base de datos de la clinica.
Script de los procedimientos almacenados.